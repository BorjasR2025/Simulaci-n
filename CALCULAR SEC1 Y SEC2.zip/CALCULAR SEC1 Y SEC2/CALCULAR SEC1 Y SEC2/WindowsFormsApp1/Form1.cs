﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            double valor1, valor2, valor3, valor4, promedio1,promedio2;
            
            valor1 = double.Parse(txtvalor1.Text);
            valor2 = double.Parse(txtvalor2.Text);
            valor3 = double.Parse(txtvalor3.Text);
            valor4 = double.Parse(txtvalor4.Text);

            promedio1 = (valor1 + valor2 )/2;
            txtpromedio1.Text = promedio1.ToString("N2");

            promedio2 = (valor3 + valor4) / 2;
            txtpromedio2.Text = promedio2.ToString("N2");

        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            txtvalor1.Clear();
            txtvalor2.Clear();
            txtvalor3.Clear();
            txtvalor4.Clear();
            txtpromedio1.Clear();
            txtpromedio2.Clear();

            txtvalor1.Focus();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
           this.Close();
        }

        
    }
}
